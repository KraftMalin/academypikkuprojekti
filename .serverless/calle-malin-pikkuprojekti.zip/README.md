# pikkuprojekti
Academyn 2019 pikkuprojekti
Tekijät: Carl Syrén & Malin Kraft
