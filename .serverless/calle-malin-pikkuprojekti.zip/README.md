# pikkuprojekti
Academyn 2019 pikkuprojekti \n
Tekijät: Carl Syrén & Malin Kraft \n


