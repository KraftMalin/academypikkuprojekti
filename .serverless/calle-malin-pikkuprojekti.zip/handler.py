import json
import boto3
import os
from botocore.vendored import requests

CHARSET = 'UTF-8'

def getEvilQuote():
    response = requests.get('https://evilinsult.com/generate_insult.php?lang=en&type=json', allow_redirects=False)
    quote = response.json()
    return quote['insult']

def parseMessageToHTML(recipient, evil_quote, message, name):
    message = '''
    <html>
    <head></head>
    <body>
    <p>
    <h1>Hi, here is a greeting for you</h1>  
    <div background-image: url("https://ih1.redbubble.net/image.646323682.6946/flat,750x,075,f-pad,750x1000,f8f8f8.jpg");>
    I hope you enjoy your holiday
    </p>
    </body>
    </html>
    '''

    return message
    


def sendEmail(event, context):
    data = event['body']
    name = data ['name']    
    source = data['source']    
    subject = data['subject']
    message = data['message']
    recipient = data['recipient']    
    destination = data['destination']
    evil_quote = getEvilQuote()
    _message = "Message from: " + name + "\nEmail: " + source + "\nMessage content: " + message 
    body_text = 'Hi ' + recipient + ', here is a seasons greeting for you: \n\n' + getEvilQuote() + '\n\n' + message 
    body_html = parseMessageToHTML(recipient, evil_quote, message, name)
    
    
    client = boto3.client('ses' )    
        
    response = client.send_email(
        Destination={
            'ToAddresses': [destination]
            },
        Message={
            'Body': {
                'Html': {
                    'Charset': CHARSET,
                    'Data': body_html,
                },
                'Text': {
                    'Data': body_text,
                    'Charset': CHARSET,
                },
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': subject,
            },
        },
        Source=source,
    )
    return 'I am sure your friend *krhm*, appriciates your effort. <br>Your friend was wished: ' + evil_quote


